<?php

session_start();

error_reporting(0);

echo $_SESSION["curr_email_user"];

?>